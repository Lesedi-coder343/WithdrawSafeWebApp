// JavaScript code should be placed here

import React from 'react';
import ReactDOM from 'react-dom';
import Home from './Home';
import Index from './index';
import logiN from './login';
<div>
    <main>
        <Home/>
        <Index/>
        <logiN/>
    </main>


</div>
